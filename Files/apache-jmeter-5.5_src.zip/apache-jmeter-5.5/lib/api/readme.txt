lib/api
=======

API specification libraries

This directory hosts binary archives for software that is not included
with the binary release, but which is needed for compiling the code.

At present this just includes the binary jars of 
the Legion of the Bouncy Castle Java cryptography APIs.
